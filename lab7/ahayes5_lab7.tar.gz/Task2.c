#include "functions.h"


int main()
{
    printf("%d\n", isArithmetic());
    return 0;
}
