/********************************
* Annie Hayes                   *
* CPSC 2310 Spring 21           *
* UserName: ahayes5             *
* Instructor: Dr. Yvon Feaster  *
*********************************/
#include "functions.h"

int main(int argc, char *argv[])
{
  char* inputFileName = argv[1];
  char* outputFileName = argv[2];
  //char choice;

  FILE* input = fopen(argv[1], "r");
  FILE* output = fopen(argv[2], "w");

  checkArgs(argc);
  checkFile(input, inputFileName);
  checkFile(output, outputFileName);
  node_t *list = createList(input, NULL);
  PrintName(output, list);
  PrintBDay(output, list);
  Song(output, list);

  /*do{
    MenuPrintEC();
    scanf("%s", &choice);
    MenuChoiceEC(choice, list, output);
  }while (choice != '5');
  */

  fclose(output);
  fclose(input);
  deleteList(&list);
  return 0;
}
