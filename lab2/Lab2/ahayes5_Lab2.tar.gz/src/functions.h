#ifndef FUNCTIONS_H
#define FUNCTIONS_H

int sum(int, int);

#endif